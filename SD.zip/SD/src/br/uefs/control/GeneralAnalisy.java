package br.uefs.control;
import br.uefs.lib.*;

public class GeneralAnalisy {
	
	
	
	public static int instrExists(String inst)
	{	
		if(inst.matches("["+Library.diretivas[0]+"-"+Library.diretivas[1]+"-"+Library.diretivas[2]+"-"+Library.diretivas[3]+"]"))
		{
			return 99;
		}
		else if(Library.instList.contains(inst))
		{
				int index = Library.instList.indexOf(inst);
				Instructions a = Library.instList.get(index);
				System.out.println(index+" -"+inst );
				return a.getType();
		}
			return 90;
	}
	

	public boolean instructionsFormatExists(String linha)
	{
	
		String [] tokens = linha.trim().split("\t");
		
		Library.instList.contains(tokens[0]);
		
		
		return false;
	}

	public static void linhaError(String linha, int numberLine) {
		// TODO Auto-generated method stub
	}
	

}
