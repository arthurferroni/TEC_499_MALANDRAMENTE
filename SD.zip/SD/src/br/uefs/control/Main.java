package br.uefs.control;

import java.io.IOException;
import java.util.HashMap;

import br.uefs.lib.Instructions;
import br.uefs.lib.Library;
import br.uefs.lib.RefInstruc;


public class Main {
	
	public static void main(String[] args) {
		
		
		try {
			Library.readerInstructions();
			Library.readerRegisters();
			ReaderFile.inputFile("teste.txt");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		MapingMemory.map();
		MapingMemory.mountBinary();
		
		
		System.out.println(	MapingMemory.memoria_flash.size() + " "+  ReaderFile.instrucoes_lidas.size());
		
	}
	
	
}
