package br.uefs.control;

import java.io.IOException;

import br.uefs.lib.Library;
import br.uefs.lib.RefInstruc;


public class Main {
	
	
	public static void main(String[] args) {
		
		try {
			Library.createInstList();
			Library.createRegList();
			ReaderFile.inputFile("teste.txt");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		/*
		for(Instructions X: Library.instList)
		{
			System.out.println(X.getName() +"\t"+ X.getType()) ;
			
		}
		for(Struct_Micro_Inst Y: Library.micro_struct_list )
		{
			System.out.println(Y.getName() + "\t" + Y.getNumberOperation()+"\t"+Y.getOpcode() + "\t"+Y.getFunct()+"" ) ;
			
		}
		*/
	}
	
}
