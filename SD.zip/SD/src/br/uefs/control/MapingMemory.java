package br.uefs.control;

import java.util.HashMap;

import br.uefs.lib.Instructions;
import br.uefs.lib.Library;
import br.uefs.lib.RefInstruc;

public class MapingMemory {
	
	static int sizeMemory = 16384;
	static String[] Memoria = new String[sizeMemory];
	static HashMap< Integer,String> memoria_flash = new HashMap<Integer,String>();
	public static void map() {
		int currentLine = 0;
		for(RefInstruc aux: ReaderFile.instrucoes_lidas)
		{
			ReaderFile.statusERROR = false;
			
			String word_32bits = null;
			int index = GeneralAnalisy.handlerTypeInstructions(aux.LinhaIntr[0]);
			Instructions Inst_Aux = null;
			
			System.err.println(index);
			if(index < 9)
				 Inst_Aux = GeneralAnalisy.getInstruction(aux.LinhaIntr[0]);	
			
			if(index == 10)
			{
				GeneralAnalisy.writerLogError("Verifique a Instru��o ou Quebra de Linha:  "+aux.LinhaIntr[0]+" - linha: "+aux.linha);				
			}
			
		if(!ReaderFile.statusERROR)
		{		
			if(index == 0){ // INSTRU��ES T - R
				int op = Inst_Aux.getOperandos();
				
				if(op==3)
				{	
					//verificando os regs 
					for(int i=1; i<=op; i++)
					{
						if(!Library.registradores.containsKey(aux.LinhaIntr[i]))
							GeneralAnalisy.writerLogError("Verifique os Registrador: "+aux.LinhaIntr[i]+" - linha: "+aux.linha);			
					}
					if(!ReaderFile.statusERROR)
					{
						word_32bits =
								Inst_Aux.getOpcode().substring(2)
								+""+Library.getCodeReg(aux.LinhaIntr[1]) // D
								+""+Library.getCodeReg(aux.LinhaIntr[2]) // T
								+""+Library.getCodeReg(aux.LinhaIntr[3]) // s
								+""+Inst_Aux.getShitfAmount().substring(3)
								+""+Inst_Aux.getFunction().substring(2);
						memoria_flash.put(currentLine,	word_32bits);
					}
				}
				else if(op==2)
				{	
					
					//verificando os regs 
					for(int i=1; i<=op; i++)
					{
						if(!Library.registradores.containsKey(aux.LinhaIntr[i]))
							GeneralAnalisy.writerLogError("Verifique os Registrador: "+aux.LinhaIntr[i]+" - linha: "+aux.linha);			
					}
					if(!ReaderFile.statusERROR)
					{
					word_32bits =
							Inst_Aux.getOpcode().substring(2)
							+""+Library.getCodeReg(aux.LinhaIntr[1]) // S
							+""+Library.getCodeReg(aux.LinhaIntr[2]) // T
							+""+Library.ZERO.substring(3)
							+""+Inst_Aux.getShitfAmount().substring(3)
							+""+Inst_Aux.getFunction().substring(2);
						memoria_flash.put(currentLine,	word_32bits);
					}
				}
				else if (op==1)
				{	
					//verificando os regs 
					for(int i=1; i<=op; i++)
					{
						if(!Library.registradores.containsKey(aux.LinhaIntr[i]))
							GeneralAnalisy.writerLogError("Verifique os Registrador: "+aux.LinhaIntr[i]+" - linha: "+aux.linha);			
					}
					if(!ReaderFile.statusERROR)
					{
					
						word_32bits =
								Inst_Aux.getOpcode().substring(2)
								+""+Library.getCodeReg(aux.LinhaIntr[1])
								+""+Library.ZERO.substring(3)
								+""+Library.ZERO.substring(3)
								+""+Inst_Aux.getShitfAmount().substring(3)
								+""+Inst_Aux.getFunction().substring(2);
					
						//System.err.println(word_32bits);
						memoria_flash.put(currentLine,	word_32bits);
					}
				}
			}
			else if(index == 1 )
			{ // INSTRU��ES T - I
					int op = Inst_Aux.getOperandos();
					
					if(op ==3)
					{	
						//verificando os regs 
						for(int i=1; i<=op-1; i++)
						{
							if(!Library.registradores.containsKey(aux.LinhaIntr[i]))
								GeneralAnalisy.writerLogError("Verifique os Registrador: "+aux.LinhaIntr[i]+" - linha: "+aux.linha);			
						}
						if( !(Integer.parseInt(aux.LinhaIntr[3])!=0 || Integer.parseInt(aux.LinhaIntr[3])==0) )
						{
							GeneralAnalisy.writerLogError("Verifique a constante: "+aux.LinhaIntr[3]+" - linha: "+aux.linha);
						}
						if(!ReaderFile.statusERROR)
						{
							word_32bits =
								Inst_Aux.getOpcode().substring(2)
								+""+Library.getCodeReg(aux.LinhaIntr[1])
								+""+Library.getCodeReg(aux.LinhaIntr[2])
								+""+Library.getBin16(aux.LinhaIntr[3]);
						
							//System.err.println(word_32bits);
							memoria_flash.put(currentLine,	word_32bits);
						}
					}
					else if(op ==2)
					{	
						//verificando os regs 
						for(int i=1; i<=op-1; i++)
						{
							if(!Library.registradores.containsKey(aux.LinhaIntr[i]))
								GeneralAnalisy.writerLogError("Verifique os Registrador: "+aux.LinhaIntr[i]+" - linha: "+aux.linha);			
						}
						if( !(Integer.parseInt(aux.LinhaIntr[2])!=0 || Integer.parseInt(aux.LinhaIntr[2])==0) )
						{
							GeneralAnalisy.writerLogError("Verifique a constante: "+aux.LinhaIntr[2]+" - linha: "+aux.linha);
						}
						if(!ReaderFile.statusERROR)
						{
						
							word_32bits =
								Inst_Aux.getOpcode().substring(2)
								+""+Library.getCodeReg(aux.LinhaIntr[1])
								+""+Library.ZERO.substring(3)
								+""+Library.getBin16(aux.LinhaIntr[2]);				
					
							//System.err.println(word_32bits);
							memoria_flash.put(currentLine,	word_32bits);
						}
					}
				}
				else if(index == 2){ // INSTRU��ES T - J
					
					
							aux.LinhaIntr[1] +=":";
							if(!Library.labellist.contains(aux.LinhaIntr[1]))
							{
								GeneralAnalisy.writerLogError("Verificar a Label: "+aux.LinhaIntr[1] + " - linha: "+aux.linha);
							}
							if(!ReaderFile.statusERROR)		
							{
							RefInstruc aux1 = new RefInstruc(aux.LinhaIntr[1].split("\t"), 1);
							//	System.err.println(aux.LinhaIntr[1]);
							aux1 = ReaderFile.instrucoes_lidas.get(ReaderFile.instrucoes_lidas.indexOf(aux1));
								
								word_32bits = 
										Inst_Aux.getOpcode().substring(2)
										+""+Library.signalExt((1+aux1.linha)+"", 26);
								//System.err.println(word_32bits);
								memoria_flash.put(currentLine,word_32bits);
							}
				}
				else if(index == 4){ 	// INSTRU��ES COM UNSINGED
					int op = Inst_Aux.getOperandos();
					if(op == 3)
					{
						for(int i=1; i<op-2; i++)
						if(Library.registradores.containsKey(aux.LinhaIntr[i]))
								GeneralAnalisy.writerLogError("Verificar os registrador: "+aux.LinhaIntr[i]+"- linha: "+aux.linha);
						if(!(Integer.parseInt(aux.LinhaIntr[3]) < 65536 && Integer.parseInt(aux.LinhaIntr[3]) > 0) )
								GeneralAnalisy.writerLogError("Verifique a faixa da constante: "+aux.LinhaIntr[3]+"- linha: "+aux.linha);// falar ERRO TODO
							
						if(!ReaderFile.statusERROR)		
						{	word_32bits =
								Inst_Aux.getOpcode().substring(2)
								+""+Library.getCodeReg(aux.LinhaIntr[1])//D
								+""+Library.getCodeReg(aux.LinhaIntr[2]) //S
								+""+Library.getBin16(aux.LinhaIntr[3]); //T
						}
					}
					else if(op == 2)
					{
						if(Library.registradores.containsKey(aux.LinhaIntr[1]))
							GeneralAnalisy.writerLogError("Verificar os registrador: "+aux.LinhaIntr[1]+"- linha: "+aux.linha);
						if(!(Integer.parseInt(aux.LinhaIntr[2]) < 65536 && Integer.parseInt(aux.LinhaIntr[2]) > 0) )
							GeneralAnalisy.writerLogError("Verifique a faixa da constante: "+aux.LinhaIntr[2]+"- linha: "+aux.linha);// falar ERRO TODO
						
							if(!ReaderFile.statusERROR)
							{
								word_32bits =
									Inst_Aux.getOpcode().substring(2)
										+""+Library.getCodeReg(aux.LinhaIntr[1])
										+""+Library.ZERO.substring(3)
										+""+Library.getBin16(aux.LinhaIntr[2]);
								
							//	System.err.println(word_32bits);
								memoria_flash.put(currentLine,word_32bits);
							}	
					}
				}
				else if(index ==5)
				{ // INSTRU��ES T - I ( L* and S*)
					String []tok = aux.LinhaIntr[2].split("[\\( - \\)]");
					if( !(Library.registradores.containsKey(tok[1]) && Library.registradores.containsKey(aux.LinhaIntr[1])))
					{
						GeneralAnalisy.writerLogError("Verificar os registradores - linha: "+aux.linha);
					}
					if(!ReaderFile.statusERROR)
					{
						word_32bits =
								Inst_Aux.getOpcode().substring(2)
								+""+Library.getCodeReg(tok[1])
								+""+Library.getCodeReg(aux.LinhaIntr[1])
								+""+Library.getBin16(tok[0]);
						System.err.println(word_32bits);
						memoria_flash.put(currentLine,word_32bits);
					}
				}
				else if(index ==6)
				{ 
					// INSTRU��ES T - R SHIFT 
					for(int i=1; i<=2; i++)
					{
						if(!Library.registradores.containsKey(aux.LinhaIntr[i]))
							GeneralAnalisy.writerLogError("Verifique os Registrador: "+aux.LinhaIntr[i]+" - linha: "+aux.linha);			
					}
					
					if( !(Integer.parseInt(aux.LinhaIntr[3])>=0 && Integer.parseInt(aux.LinhaIntr[3])<=31))
						GeneralAnalisy.writerLogError("Verifique a Constante: "+aux.LinhaIntr[3]+" - linha: "+aux.linha);
					
					if(!ReaderFile.statusERROR)
					{
						word_32bits =
								Inst_Aux.getOpcode().substring(2)
								+" "+Library.getCodeReg(aux.LinhaIntr[1]) // D
								+" "+Library.getCodeReg(aux.LinhaIntr[2]) // T
								+" "+Library.ZERO.substring(3) // s
								+" "+Library.signalExt(aux.LinhaIntr[3], 5)
								+" "+Inst_Aux.getFunction().substring(2);
					//	System.err.println(word_32bits);
						memoria_flash.put(currentLine, word_32bits);
					}
				}
				else if(index ==7)
				{ // Intru��es BEQ , BEQZ, BNE, BNEZ
					aux.LinhaIntr[3] +=":";
					for(int i=1; i<=2; i++)
					{
						if(!Library.registradores.containsKey(aux.LinhaIntr[i]))
							GeneralAnalisy.writerLogError("Verifique os Registrador: "+aux.LinhaIntr[i]+" - linha: "+aux.linha);			
					}
					if( !Library.labellist.contains(aux.LinhaIntr[3]) )
					{
						GeneralAnalisy.writerLogError("Verificar a Label: "+aux.LinhaIntr[3] + " - linha: "+aux.linha);
					}
					if(!ReaderFile.statusERROR)
					{
					
						RefInstruc aux1 = new RefInstruc(aux.LinhaIntr[3].split("\t"), 1);
						System.err.println(aux.LinhaIntr[3]);
						aux1 = ReaderFile.instrucoes_lidas.get(ReaderFile.instrucoes_lidas.indexOf(aux1));
						
							word_32bits = 
									Inst_Aux.getOpcode().substring(2)
									+" "+Library.getCodeReg(aux.LinhaIntr[1])
									+" "+Library.getCodeReg(aux.LinhaIntr[2])
									+" "+Library.signalExt((aux1.linha-currentLine)+"", 16);
							
							//System.err.println(word_32bits);
							memoria_flash.put(currentLine,word_32bits);
					}
				}
				currentLine++;
			}
		}
		
	}
	public static void mountBinary() {
		int currentLine = 1;
		if(ReaderFile.erros == 0 )
		{
			for(RefInstruc aux: ReaderFile.instrucoes_lidas)
			{
				
				
				
				if(currentLine>sizeMemory)
				{
					GeneralAnalisy.writerLogError("N�o h� mem�ria suficiente para montar esse arquivo." );
					break;
				}
			}
		}else
		{
			GeneralAnalisy.writerLogError("Impossiv�l montar o arquivo bin�rio existem " + ReaderFile.erros+" erros no c�digo." );
		}
	}

}
