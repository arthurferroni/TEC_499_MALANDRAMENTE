package br.uefs.control;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.LinkedList;

import br.uefs.lib.Library;
import br.uefs.lib.RefInstruc;

public class ReaderFile {
	
	public static LinkedList<RefInstruc> instrucoes_lidas = new LinkedList<RefInstruc>();
	static int numberLine=1;
	public static void inputFile(String name) throws IOException{
		FileInputStream stream = null;
		stream = new FileInputStream(name);
		InputStreamReader reader = new InputStreamReader(stream);
		BufferedReader br = new BufferedReader(reader);
		String linha = br.readLine();

		while(linha != null) {
			String aux = linha;	
			
			if(linha.matches("\\w+\\d*?\\:$"))
			{	
				Library.labellist.add(aux);				
			}
			RefInstruc x = new RefInstruc(aux.split("\t"),numberLine);
			instrucoes_lidas.add(x);
			numberLine++;
			linha = br.readLine();
		}
		br.close();
	}
}

/*ESCREVER*/
//   FileWriter fileW = new FileWriter ("t.txt");//arquivo para escrita
//   BufferedWriter buffW = new BufferedWriter (fileW);
	

/*
	aux= aux.replace(" ", "\t");
String [] tok  = aux.split("\t");
	
	if(tok[0].matches("\\w+I$"))
		buffW.write (tok[0]+"\t"+1);//Leia um arquivo e Escreva no outro
	else if (tok[0].matches("\\w+IU$"))
		buffW.write (tok[0]+"\t"+1);//Leia um arquivo e Escreva no outro
	else
	buffW.write (tok[0]+"\t"+0);//Leia um arquivo e Escreva no outro
	
    buffW.newLine ();//pula uma linha no arquivoescrever (result);
*/
