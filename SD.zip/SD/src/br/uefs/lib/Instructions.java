package br.uefs.lib;

import java.util.Comparator;

public class Instructions  {
	
	private String name;
	private int type;
	
	public Instructions(String string, String string3) {
		super();
		setName(string);
		setType(Integer.parseInt(string3));
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	public int getType() {
		return type;
	}
	public void setType(int value) {
		this.type = value;
	}

	public boolean equals(Object o)
	{
		if(o instanceof Instructions && (((Instructions)o).getName() == this.name) )
		return true;
		return false;
		
	}
	
}
