package br.uefs.lib;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.LinkedList;

import br.uefs.control.ReaderFile;

public class Library {
	
		public static LinkedList<Instructions> list_instructions = new LinkedList<Instructions>();
		public static String[] diretivas = {".dseg",".pseg",".end",".module",".word"};
		public static LinkedList<String> labellist = new LinkedList<String>();	
		public static HashMap<String, Integer> registradores = new HashMap<String, Integer>();
		public static String ZERO ="0b000000";
		
		//FUNCTIONS
		public static void readerRegisters() throws IOException
		{
			FileInputStream stream = null;
			stream = new FileInputStream("registers.txt");
			InputStreamReader reader = new InputStreamReader(stream);
			BufferedReader br = new BufferedReader(reader);
			String linha = br.readLine();
			while(linha != null) {
					String[] tokens =  linha.split("[\\t - \\s]");
					registradores.put(tokens[0],Integer.parseInt(tokens[1]));
					//System.err.println(tokens[0]+ " - "+Integer.parseInt(tokens[1]));
				linha = br.readLine();
			}
		}
		public static void readerInstructions() throws IOException
		{
			FileInputStream stream = null;
			stream = new FileInputStream("mnemonico.txt");
			InputStreamReader reader = new InputStreamReader(stream);
			BufferedReader br = new BufferedReader(reader);
			String linha = br.readLine();
			Instructions temp = null;
			int type;
			while(linha != null) {
					String[] tokens =  linha.trim().split("[\\t - \\s]");
					type  =Integer.parseInt(tokens[1]);
					
					if(type==0)
						temp = new Instructions(tokens[0], tokens[3],tokens[2],ZERO,tokens[1],ZERO);
					else if (type==1) 
						temp = new Instructions(tokens[0], tokens[3],ZERO,tokens[2],tokens[1],ZERO);
					else if(type == 2)
						temp = new Instructions(tokens[0], tokens[3],ZERO,tokens[2],tokens[1],ZERO);

					list_instructions.add(temp);
					
					System.out.println(temp.getName()+"\t"+temp.getType()+"\t"+temp.getOperandos()+"\t"+temp.getOpcode()+"\t"+temp.getFunction()+".");
				
				linha = br.readLine();
			}
		}
		public static String getCodeReg(String string) {
			Integer bin = registradores.get(string);
			return signalExt(bin.toString(),5);
		}
		public static int getAddress(String string) {
			return 0;	
		}
		
		
		public static int getOU(String string, String string2) {
			// TODO Auto-generated method stub
			return 0;
		}
		
		
		public static String signalExt(String number, int qnt)
		{
			String binario = "",aux="" ;
			String []splitBin;
			Integer bin = Integer.parseInt(number);
			
			if(bin>=0){
			binario = Integer.toBinaryString(bin);
			splitBin = binario.split("");
			for(int i = splitBin.length ; i<qnt; i++)
			{
				aux +="0";
			}
				return aux+binario ;
			}
			else
				return Integer.toBinaryString(bin).substring(qnt);	
		}
		
		public static String getBin16(String string) {
			
			return signalExt(string,16) ;
		}
		public static String getBin32(String string) {
			
			return signalExt(string,32);
		}



}
