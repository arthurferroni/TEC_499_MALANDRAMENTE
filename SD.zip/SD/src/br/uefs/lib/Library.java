package br.uefs.lib;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.LinkedList;

public class Library {
	
		public static LinkedList<Instructions> instList = new LinkedList<Instructions>();
		public static LinkedList<Registers> reg_list = new LinkedList<Registers>();	
		public static String[] diretivas = {".dseg",".pseg",".end",".module"};
		public static LinkedList<String> labellist = new LinkedList<String>();	
		
		
		
		public static void createInstList() throws IOException
		{
			FileInputStream stream = null;
			stream = new FileInputStream("mnemonico.txt");
			InputStreamReader reader = new InputStreamReader(stream);
			BufferedReader br = new BufferedReader(reader);
			String linha = br.readLine();
			while(linha != null) {
				if(linha != null)
				{
					String[] tokens =  linha.trim().split("\t");
					Instructions temp = new Instructions(tokens[0],tokens[1]);
					instList.add(temp);
				}
				linha = br.readLine();
			}
		}
				
		public static void createRegList() throws IOException
		{
			FileInputStream stream = null;
			stream = new FileInputStream("reg.txt");
			InputStreamReader reader = new InputStreamReader(stream);
			BufferedReader br = new BufferedReader(reader);
			String linha = br.readLine();
			while(linha != null) {
				
				if(linha != null)
				{
					String[] tokens =  linha.split("\t");
					Registers temp = new Registers(tokens[0],Integer.parseInt(tokens[1]) ,Integer.parseInt(tokens[2]));
					reg_list.add(temp);
				}
				linha = br.readLine();
			}
		}


}
