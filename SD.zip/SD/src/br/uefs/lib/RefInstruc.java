package br.uefs.lib;

public class RefInstruc {
	
	public String []LinhaIntr;
	public int linha;
	
	public RefInstruc(String[] linha2, int numberLine) {
		super();
		LinhaIntr = linha2;
		linha = numberLine;
	}
}
