package br.uefs.lib;

public class RefInstruc {
	
	public String []LinhaIntr;
	public int linha;
	
	public RefInstruc(String[] linha2, int numberLine) {
		super();
		LinhaIntr = linha2;
		linha = numberLine;
	}
	public boolean equals(Object o){
		
		if(o instanceof RefInstruc && ((RefInstruc)o).LinhaIntr[0].equals(LinhaIntr[0])) return true;
		return false;
	}
}
